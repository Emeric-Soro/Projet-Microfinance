package com.microfinance.core_banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
